#include "cBird.h"

const int cBird::Width = 68;
const int cBird::Height = 68;
//
//cBird::cBird(cContentManager *Content, cAudio *Audio, Vector Position, Vector Velocity, int Number, float BoundingPercent, cPlayer *Player) :
//		m_Audio(Audio),
//		m_Position(Position),
//		m_Velocity(Velocity),
//		m_Number(Number),
//		m_BoundingPercent(BoundingPercent),
//		m_Player(Player)
cBird::cBird(cContentManager *Content, cAudio *Audio, Vector Position, Vector Velocity, int Number, cPlayer *Player) :
		m_Audio(Audio),
		m_Position(Position),
		m_Velocity(Velocity),
		m_Number(Number),
		m_BoundingPercent(0.8f),
		m_Player(Player)
{
	m_IsAlive = true;

	m_AnimPlayer = new cAnimationPlayer();
	m_OnMoveAnim = new cAnimation(Content->LoadTexture("Images\\Birds\\" + IntToString(m_Number) + ".png"), 1.0, false);
	m_OnDie = new cAnimation(Content->LoadTexture("Images\\Birds\\BirdsDie.png"), 0.05f, false);
	m_AnimPlayer->Play(m_OnMoveAnim);
	
	m_Flip = (CenterDistancePercent > 0 ? TextureFlip_FlipHorizontally : TextureFlip_None);
}

cBird::~cBird(void)
{
	delete m_OnMoveAnim;
	delete m_OnDie;
}

void cBird::HandleCollision()
{
	if (m_Player->InShooting && m_Player->BoundingRectangle.Contains(BoundingRectangle))
	{
		OnDie();
	}

	if (BoundingRectangle.Left < 0)
	{
		m_Position.X -= BoundingRectangle.Left;
		
		m_Velocity.X = -m_Velocity.X;
	}
	
	if (BoundingRectangle.Right > WIDTH)
	{
		int x = ((m_AnimPlayer->Animation->FrameWidth - BoundingRectangle.Width) / 2.0f);
		
		m_Position.X = WIDTH - m_AnimPlayer->Animation->FrameWidth + x;
		
		m_Velocity.X = -m_Velocity.X;
	}

	if (m_Velocity.X > 0)
		m_Flip = TextureFlip_None;
	else
		m_Flip = TextureFlip_FlipHorizontally;
}

void cBird::Update(cGameTime *GameTime)
{
	m_Position += m_Velocity;

	HandleCollision();

	m_OnMoveAnim->Texture->Effect->Flip = m_Flip;
}

void cBird::Draw(cGameTime *GameTime, cSpriteBatch *SpriteBatch)
{
	m_AnimPlayer->Draw(GameTime, SpriteBatch, m_Position);
}

void cBird::OnDie()
{
	if (m_IsAlive)
	{
		m_IsAlive = false;

		m_Velocity.Y = -m_Velocity.Y;

		m_AnimPlayer->Play(m_OnDie);

		m_Audio->Play("Data\\Sounds\\BirdDestroyed" + IntToString(m_Number) + ".wav")->Pan = CenterDistancePercent;

		m_Player->Score += (30 * m_Number);
	}
}