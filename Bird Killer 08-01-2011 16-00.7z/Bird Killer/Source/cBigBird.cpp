#include "cBigBird.h"

const int cBigBird::Width = 100;
const int cBigBird::Height = 100;

cBigBird::cBigBird(cContentManager *Content, cAudio *Audio, Vector Position, Vector Velocity, int Number, cPlayer *Player) :
		m_Audio(Audio),
		m_Position(Position),
		m_Velocity(Velocity),
		m_Number(Number),
		m_BoundingPercent(0.8f),
		m_Player(Player)
{
	m_IsAlive = true;
	m_IsInScene = false;

	m_AnimPlayer = new cAnimationPlayer();
	m_OnMoveAnim = new cAnimation(Content->LoadTexture("Images\\BigBirds\\" + IntToString(m_Number) + ".png"), 1.0, false);
	m_OnDie = new cAnimation(Content->LoadTexture("Images\\BigBirds\\BigBirdsDie.png"), 0.08f, false);
	m_AnimPlayer->Play(m_OnMoveAnim);
	
	m_Flip = (CenterDistancePercent > 0 ? TextureFlip_FlipHorizontally : TextureFlip_None);

	m_HitCount = 0;
}

cBigBird::~cBigBird(void)
{
	delete m_OnMoveAnim;
	delete m_OnDie;
}

void cBigBird::HandleCollision()
{
	if (!m_IsInScene)
		m_IsInScene = (BoundingRectangle.Top > 0);

	if (m_Player->InShooting && m_Player->BoundingRectangle.Contains(BoundingRectangle))
	{
		if (m_HitCount == 3)
			OnDie();
		else
		{
			m_HitCount++;
			m_Velocity.Y = -Abs(m_Velocity.Y);
		}
	}

	if (BoundingRectangle.Left < 0)
	{
		m_Position.X -= BoundingRectangle.Left;
		
		m_Velocity.X = -m_Velocity.X;
	}
	
	if (BoundingRectangle.Right > WIDTH)
	{
		int x = ((m_AnimPlayer->Animation->FrameWidth - BoundingRectangle.Width) / 2.0f);
		
		m_Position.X = WIDTH - m_AnimPlayer->Animation->FrameWidth + x;
		
		m_Velocity.X = -m_Velocity.X;
	}
	
	if (m_IsInScene && BoundingRectangle.Top <= 0)
	{
		m_Velocity.Y = -m_Velocity.Y;
	}

	if (m_Velocity.X > 0)
		m_Flip = TextureFlip_None;
	else
		m_Flip = TextureFlip_FlipHorizontally;
}

void cBigBird::Update(cGameTime *GameTime)
{
	m_Position += m_Velocity;

	HandleCollision();

	m_OnMoveAnim->Texture->Effect->Flip = m_Flip;
}

void cBigBird::Draw(cGameTime *GameTime, cSpriteBatch *SpriteBatch)
{
	m_AnimPlayer->Draw(GameTime, SpriteBatch, m_Position);
}

void cBigBird::OnDie()
{
	if (m_IsAlive)
	{
		m_IsAlive = false;

		m_Velocity.Y = -m_Velocity.Y;

		m_AnimPlayer->Play(m_OnDie);

		m_Audio->Play("Data\\Sounds\\BigBirdDestroyed.wav")->Pan = CenterDistancePercent;

		m_Player->Score += (30 * m_Number);
	}
}
