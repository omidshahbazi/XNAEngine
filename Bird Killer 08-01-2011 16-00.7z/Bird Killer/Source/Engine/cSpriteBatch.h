#pragma once

#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_image.h>
#include <SDL_rotozoom.h>
#include <SDL_gfxPrimitives.h>
#include <vector>
#include "Sprite.h"
#include "cTexture.h"
#include "cFont.h"
#include "Rectangle.h"
#include "Vector.h"
#include "Color.h"

class cSpriteBatch
{
public:
	cSpriteBatch(SDL_Surface* BackBuffer);
	~cSpriteBatch(void)
	{
		SDL_FreeSurface(m_BackBuffer);

		TTF_Quit();
	}

public:
	void Clear(Color BackColor = Color(0, 0, 0));

	void Draw(cTexture* Texture, Vector DestinationVector);
	void Draw(cTexture* Texture, Vector SourceVector, Vector DestinationVector);
	void Draw(cTexture* Texture, Rectangle SourceRectangle, Vector DestinationVector);
	void Draw(cTexture* Texture, Rectangle SourceRectangle, Rectangle DestinationRectangle);

	void Flip(cTexture *&Texture);
	SDL_Surface* Flip(SDL_Surface *Surface, TextureEffects *Effect);

	void DrawString(cFont *Font, std::string Text, Vector Position, Color ForeColor);
	void DrawString(cFont *Font, std::string Text, Vector Position, Color ForeColor, TextureEffects *Effects);
	void DrawString(cFont *Font, std::string Text, Vector Position, Color ForeColor, Color BackColor);
	void DrawString(cFont *Font, std::string Text, Vector Position, Color ForeColor, Color BackColor, TextureEffects *Effects);

	//void DrawStringUnicode(cFont *Font,  Uint16 *Text, Vector Position, Color ForeColor);

	void DrawRectangle(Rectangle Rect, bool Filled = false, Color Color = Color(0, 0, 0));

	void Flush(void);

	void SaveScreen(std::string FilePath);
	
	__declspec(property(get = GetBackColor)) Color BackColor;
	Color GetBackColor(void) { return m_BackColor; }

private:
	static Uint32 GetPixel(SDL_Surface *Surface, int X, int Y);
	static void PutPixel(SDL_Surface *Surface, int X, int Y, Uint32 PixelColor);

	void DrawStringCore(SDL_Surface *temp, Rectangle DestinationRectangle, TextureEffects *Effects);

	void DrawCore(cTexture* Texture, Rectangle SourceRectangle, Rectangle DestinationRectangle);

private:
	std::vector<Sprite*> m_SpriteList;
	SDL_Surface *m_BackBuffer;
	Color m_BackColor;
};

