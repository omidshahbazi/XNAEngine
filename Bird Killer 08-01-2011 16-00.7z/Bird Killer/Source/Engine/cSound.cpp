#include "cSound.h"

cSound::cSound(ISound *Sound)
{
	m_Sound = Sound;
}

cSound::~cSound(void)
{
	delete m_Sound;
}

void cSound::Resume()
{
	m_Sound->setIsPaused(false);
}

void cSound::Pause()
{
	m_Sound->setIsPaused(true);
}

void cSound::Stop()
{
	m_Sound->stop();
}