#pragma once

#include <SDL.h>
#include <SDL_ttf.h>
#include <string>
#include "Color.h"
#include "Size.h"

typedef enum FontStyle
{
	FontStyle_Normal = 0,
	FontStyle_Bold = 1,
	FontStyle_Italic = 2,
	FontStyle_Underline = 4
} FontStyle;

class cFont
{
public:
	cFont()
	{
		m_Font = 0;
	}

	cFont(TTF_Font* Font)
	{
		m_Font = Font;
	}

	~cFont(void)
	{
		TTF_CloseFont(m_Font);
	}

public:
	bool GetStyle(int Style);
	void SetStyle(int Style);
	Size GetSize(std::string Text);

	static cFont* FromFile(std::string FileName, int Size);
	
	__declspec(property(get = GetFont)) TTF_Font* Font;
	TTF_Font* GetFont(void) { return m_Font; }

	__declspec(property(get = GetBold, put = SetBold)) bool Bold;
	bool GetBold(void) { return GetStyle(FontStyle_Bold); }
	void SetBold(bool Value)
	{
		if (Value)
			SetStyle(FontStyle_Bold);
		else
			SetStyle(FontStyle_Normal);
	}

	__declspec(property(get = GetItalic, put = SetItalic)) bool Italic;
	bool GetItalic(void) { return GetStyle(FontStyle_Italic); }
	void SetItalic(bool Value)
	{
		if (Value)
			SetStyle(FontStyle_Italic);
		else
			SetStyle(FontStyle_Normal);
	}

	__declspec(property(get = GetUnderline, put = SetUnderline)) bool Underline;
	bool GetUnderline(void) { return GetStyle(FontStyle_Underline); }
	void SetUnderline(bool Value)
	{
		if (Value)
			SetStyle(FontStyle_Underline);
		else
			SetStyle(FontStyle_Normal);
	}
	
private:
	TTF_Font* m_Font;
};

