#include "cGameWindow.h"

SDL_Surface* cGameWindow::CreateWindow(void)
{
	return cGameWindow::CreateWindow(false, false);
}

SDL_Surface* cGameWindow::CreateWindow(bool FullScreen)
{
	return cGameWindow::CreateWindow(FullScreen, false);
}

SDL_Surface* cGameWindow::CreateWindow(bool FullScreen, bool DoubleBuffer)
{
	//videoFlags |= SDL_HWPALETTE;       /* Store the palette in hardware */
	//videoFlags |= SDL_RESIZABLE;       /* Enable window resizing */

	///* This checks to see if surfaces can be stored in memory */
	//if ( videoInfo->hw_available )
	//	videoFlags |= SDL_HWSURFACE;
	//else
	//	videoFlags |= SDL_SWSURFACE;

	///* This checks if hardware blits can be done */
	//if ( videoInfo->blit_hw )
	//	videoFlags |= SDL_HWACCEL;

	//SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER,        1);	// tell SDL that the GL drawing is going to be double buffered

	//SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, SCREEN_BPP);	// size of depth buffer

	//SDL_GL_SetAttribute(SDL_GL_STENCIL_SIZE,        0);	// we aren't going to use the stencil buffer

	//SDL_GL_SetAttribute(SDL_GL_ACCUM_RED_SIZE,      0);	// this and the next three lines set the bits allocated per pixel -

	//SDL_GL_SetAttribute(SDL_GL_ACCUM_GREEN_SIZE,    0);	// - for the accumulation buffer to 0

	//SDL_GL_SetAttribute(SDL_GL_ACCUM_BLUE_SIZE,     0);
	//SDL_GL_SetAttribute(SDL_GL_ACCUM_ALPHA_SIZE,    0);

	int flags = 0;

	flags |= SDL_ANYFORMAT;

	if (FullScreen)
	{
		flags |= SDL_FULLSCREEN;
		
		if (m_GetScreenSize)
		{
			const SDL_VideoInfo* videoInfo = SDL_GetVideoInfo();

			m_width = videoInfo->current_w;
			m_height = videoInfo->current_h;
		}
	}

	if (DoubleBuffer)
		flags |= SDL_DOUBLEBUF;

	m_BackBuffer = SDL_SetVideoMode(m_width, m_height, 32, flags);

	if (FullScreen)
		SDL_WM_ToggleFullScreen(m_BackBuffer);

	SetCaption(m_Caption);
	
	return m_BackBuffer;
}

void cGameWindow::SetCaption(std::string Caption)
{
	m_Caption = Caption;
	
	SDL_WM_SetCaption(("Aban Engine - " + m_Caption).c_str(), 0);
}

void cGameWindow::SetIcon(std::string FileName)
{
	SetIcon(IMG_Load(FileName.c_str()));
}

void cGameWindow::SetIcon(SDL_Surface *Icon)
{
	SDL_WM_SetIcon(Icon, NULL);
}