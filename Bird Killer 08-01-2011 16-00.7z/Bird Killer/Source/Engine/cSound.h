#pragma once

#include <irrKlang.h>
#include <string>

using namespace irrklang;

class cSound
{
public:
	cSound(ISound *Sound);
	~cSound(void);

public:
	__declspec(property(get = GetIsLooped, put = SetIsLooped)) bool IsLooped;
	bool GetIsLooped(void) { return m_Sound->isLooped(); }
	void SetIsLooped(bool Value) { m_Sound->setIsLooped(Value); }

	__declspec(property(get = GetIsPaused, put = SetIsPaused)) bool IsPaused;
	bool GetIsPaused(void) { return m_Sound->getIsPaused(); }
	void SetIsPaused(bool Value) { m_Sound->setIsPaused(Value); }

	__declspec(property(get = GetIsFinished)) bool IsFinished;
	bool GetIsFinished(void) { return m_Sound->isFinished(); }

	__declspec(property(get = GetVolume, put = SetVolume)) int Volume;
	int GetVolume(void) { return m_Sound->getVolume() * 100; }
	void SetVolume(int Value) { m_Sound->setVolume(Value / 100.0f); }

	__declspec(property(get = GetPan, put = SetPan)) int Pan;
	int GetPan(void) { return m_Sound->getPan() * 100; }
	void SetPan(int Value) { m_Sound->setPan(Value / 100.0f); }

	void Resume(void);
	void Pause(void);
	void Stop(void);

private:
	ISound *m_Sound;
};
