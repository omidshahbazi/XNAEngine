#pragma once

#include "cTexture.h"
#include "Rectangle.h"
#include "Vector.h"

enum SpriteType
{
	SpriteType_Text = 0,
	SpriteType_Texture = 1
};

struct Sprite
{
public:
	// Text Sprites
	Sprite(cTexture *Texture, 
		Rectangle DestinationRectangle) :

		m_Texture(Texture), 
		m_DestinationRectangle(DestinationRectangle), 
		m_Type(SpriteType_Text)
		{}
	// Texture Sprites
	Sprite(cTexture *Texture, 
		Rectangle SourceRectangle, 
		Rectangle DestinationRectangle) :

		m_Texture(Texture), 
		m_SourceRectangle(SourceRectangle), 
		m_DestinationRectangle(DestinationRectangle), 
		m_Type(SpriteType_Texture)
		{}

public:
	__declspec(property(get = GetSurfaceType)) SpriteType SurfaceType;
	SpriteType GetSurfaceType(void) { return m_Type; }

	__declspec(property(get = GetTexture)) cTexture* Texture;
	cTexture* GetTexture(void) { return m_Texture; }
	
	__declspec(property(get = GetSourceRectangle)) Rectangle SourceRectangle;
	Rectangle GetSourceRectangle(void) { return m_SourceRectangle; }
	
	__declspec(property(get = GetDestinationRectangle)) Rectangle DestinationRectangle;
	Rectangle GetDestinationRectangle(void) { return m_DestinationRectangle; }

private:
	SpriteType m_Type;
	cTexture *m_Texture;
	Rectangle m_SourceRectangle;
	Rectangle m_DestinationRectangle;
};