#pragma once

#include <SDL.h>
#include <SDL_image.h>
#include <string>
#include "Color.h"
#include "Vector.h"

enum TextureFlip
{
	TextureFlip_None = 0,
    TextureFlip_FlipHorizontally = 1,
    TextureFlip_FlipVertically = 256,
};
struct TextureEffects
{
public:
	TextureEffects() :
			m_Flip(TextureFlip_None),
			m_Rotation(0.0f),
			m_RotationAround(Vector()),
			m_ZoomX(1.0f),
			m_ZoomY(1.0f),
			m_Smooth(10),
			m_Origin(Vector()),
			m_Alpha(255),
			m_Gamma(NULL)
		{
		}

public:
	__declspec(property(get = GetFlip, put = SetFlip)) TextureFlip Flip;
	TextureFlip GetFlip(void) { return m_Flip; }
	void SetFlip(TextureFlip Value) { m_Flip = Value; }

	__declspec(property(get = GetRotation, put = SetRotation)) double Rotation;
	double GetRotation(void) { return m_Rotation; }
	void SetRotation(double Value) { m_Rotation = Value; }
	
	__declspec(property(get = GetRotationAround, put = SetRotationAround)) Vector RotationAround;
	Vector GetRotationAround(void) { return m_RotationAround; }
	void SetRotationAround(Vector Value) { m_RotationAround = Value; }
	
	__declspec(property(get = GetZoomX, put = SetZoomX)) double ZoomX;
	double GetZoomX(void) { return m_ZoomX; }
	void SetZoomX(double Value) { m_ZoomX = Value; }
	
	__declspec(property(get = GetZoomY, put = SetZoomY)) double ZoomY;
	double GetZoomY(void) { return m_ZoomY; }
	void SetZoomY(double Value) { m_ZoomY = Value; }
	
	__declspec(property(get = GetSmooth, put = SetSmooth)) int Smooth;
	int GetSmooth(void) { return m_Smooth; }
	void SetSmooth(int Value) { m_Smooth = Value; }
	
	__declspec(property(get = GetOrigin, put = SetOrigin)) Vector Origin;
	Vector GetOrigin(void) { return m_Origin; }
	void SetOrigin(Vector Value) { m_Origin = Value; }
	
	__declspec(property(get = GetAlpha, put = SetAlpha)) int Alpha;
	int GetAlpha(void) { return m_Alpha; }
	void SetAlpha(int Value) { m_Alpha = Value; }
	
	__declspec(property(get = GetGamma, put = SetGamma)) Color *Gamma;
	Color *GetGamma(void) { return m_Gamma; }
	void SetGamma(Color *Value) { m_Gamma = Value; }

private:
	TextureFlip m_Flip;
	double m_Rotation;
	Vector m_RotationAround;
	double m_ZoomX;
	double m_ZoomY;
	int m_Smooth;
	Vector m_Origin;
	int m_Alpha;
	Color *m_Gamma;
};

class cTexture
{
public:
	cTexture()
	{
		cTexture::m_Buffer = 0;
		cTexture::m_Effect = new TextureEffects();
	}

	cTexture(SDL_Surface* Buffer)
	{
		cTexture::m_Buffer = Buffer;
		cTexture::m_Effect = new TextureEffects();
	}

	~cTexture(void)
	{
		if (m_Buffer)
			SDL_FreeSurface(m_Buffer);
	}

public:
	void SetTransparentColor(Color TransparentColor);
	static void SetTransparentColor(SDL_Surface* Surface, Color TransparentColor);
	static cTexture* FromFile(std::string FileName, bool IsAlphaBlending = true);
	static cTexture* FromFile(std::string FileName, Color TransparentColor);
	
	__declspec(property(get = GetBuffer)) SDL_Surface* Buffer;
	SDL_Surface* GetBuffer(void) { return m_Buffer; }

	__declspec(property(get = GetWidth)) int Width;
	int GetWidth(void) 
	{
		if (m_Buffer)
			return (m_Buffer->clip_rect.w); 
		
		return 0;
	}
	__declspec(property(get = GetHeight)) int Height;
	int GetHeight(void) 
	{
		if (m_Buffer)
			return (m_Buffer->clip_rect.h); 
	
		return 0;
	}

	__declspec(property(get = GetCenter)) Vector Center;
	Vector GetCenter(void) { return Vector(Width / 2.0f, Height / 2.0f); }

	__declspec(property(get = GetEffect, put = SetEffect)) TextureEffects *Effect;
	TextureEffects* GetEffect(void) { return m_Effect; }
	void SetEffect(TextureEffects *Value) { m_Effect = Value; }

private:
	SDL_Surface* m_Buffer;
	TextureEffects *m_Effect;
};

