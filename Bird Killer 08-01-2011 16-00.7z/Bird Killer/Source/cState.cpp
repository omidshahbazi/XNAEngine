#include "cState.h"

cState::cState(cInput *Input, cContentManager *Content, cAudio *Audio) :
		m_Input(Input),
		m_Content(Content), 
		m_Audio(Audio)
{
}

cState::~cState(void)
{
}

void cState::LoadState()
{
}

void cState::HandleInput()
{
	
}

void cState::Update(cGameTime *GameTime)
{

}

void cState::Draw(cGameTime *GameTime, cSpriteBatch *SpriteBatch)
{

}