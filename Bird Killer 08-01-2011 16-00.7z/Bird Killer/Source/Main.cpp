
#include "Defines.h"
#include "cBirdKillerGame.h"

//
// Fun For XNA Source Code
// XNA written based on SDL API :D ;)
// http://code.google.com/p/monoxna/source/browse
// O.Shahabazi
//

int main(int arg, char** args)
{
	cBirdKillerGame* game = new cBirdKillerGame();

	game->Run(false, WIDTH, HEIGHT, "Bird Killer");

	delete game;

	return 0;
}