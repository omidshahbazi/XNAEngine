#pragma once

#include "Engine\cGameTime.h"
#include "Engine\cContentManager.h"
#include "Engine\cAudio.h"
#include "Engine\cSpriteBatch.h"
#include "Defines.h"
#include "cPlayer.h"

class cBigBird
{
public:
	static const int Width;
	static const int Height;

public:
	//cBird(cContentManager *Content, cAudio *Audio, Vector Position, Vector Velocity, int Number, float BoundingPercent, cPlayer *Player);
	cBigBird(cContentManager *Content, cAudio *Audio, Vector Position, Vector Velocity, int Number, cPlayer *Player);
	~cBigBird(void);

	void HandleCollision(void);
	void Update(cGameTime *GameTime);
	void Draw(cGameTime *GameTime, cSpriteBatch *SpriteBatch);

	__declspec(property(get = GetCanRemove)) bool CanRemove;
	bool GetCanRemove(void) 
	{
		return (m_AnimPlayer->FrameIndex + 1 >= m_OnDie->FrameCount || 
			BoundingRectangle.Top >= HEIGHT ||
			BoundingRectangle.Right <= 0 ||
			BoundingRectangle.Left >= WIDTH); 
	}

private:
	void OnDie(void);

	__declspec(property(get = GetBoundingRectangle)) Rectangle BoundingRectangle;
	Rectangle GetBoundingRectangle(void)
	{
		int realWidth = cBigBird::Width * m_BoundingPercent;

		Rectangle rect;

		rect.X = m_Position.X + ((cBigBird::Width - realWidth) / 2.0f);
		rect.Y = m_Position.Y;
		rect.Width = realWidth;
		rect.Height = cBigBird::Height;

		return rect;
	}

	__declspec(property(get = GetCenterDistancePercent)) int CenterDistancePercent;
	int GetCenterDistancePercent(void) 
	{
		int center = BoundingRectangle.Center.X,
			windowCenter = WIDTH / 2;

		if (center == windowCenter)
			return 0;

		int temp = (Abs((windowCenter - center)) / (float)windowCenter) * 100;

		if (center > windowCenter)
			temp *= -1;

		return temp;
	}

	__declspec(property(get = GetAudio)) cAudio *Audio;
	cAudio* GetAudio(void) { return m_Audio; }

private:
	int m_Number;

	Vector m_Velocity;
	cAudio *m_Audio;
	Vector m_Position;
	Rectangle m_SrcRect;

	cAnimation *m_OnMoveAnim, *m_OnDie;
	cAnimationPlayer *m_AnimPlayer;
	float m_BoundingPercent;
	TextureFlip m_Flip;

	cPlayer *m_Player;

	bool m_IsInScene;
	bool m_IsAlive;

	int m_HitCount;
};
