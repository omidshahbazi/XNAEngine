#pragma once

#include "Defines.h"
#include "Engine\cGameTime.h"
#include "Engine\cInput.h"
#include "Engine\cContentManager.h"
#include "Engine\cAudio.h"
#include "Engine\cSpriteBatch.h"
#include "Engine\cAnimationPlayer.h"

class cPlayer
{
private:
	static const float MoveVelocity;

public:
	cPlayer(cInput *Input, cContentManager *Content, cAudio *Audio, Vector Position);
	~cPlayer(void);

	void HandleInput(void);
	void HandleCollision(void);
	void Update(cGameTime *GameTime);
	void Draw(cGameTime *GameTime, cSpriteBatch *SpriteBatch);

	__declspec(property(get = GetBoundingRectangle)) Rectangle BoundingRectangle;
	Rectangle GetBoundingRectangle(void)
	{
		int realWidth = m_AnimPlayer->Animation->FrameWidth * 0.52f;
		int realHeight = m_AnimPlayer->Animation->FrameHeight * 0.8f;

		Rectangle rect;

		rect.X = m_Position.X + ((m_AnimPlayer->Animation->FrameWidth - realWidth) / 2.0f);
		rect.Y = m_Position.Y - m_AnimPlayer->Animation->Texture->Height + ((m_AnimPlayer->Animation->FrameHeight - realHeight) / 2.0f);
		rect.Width = realWidth;
		rect.Height = realHeight;

		return rect;
	}

	__declspec(property(get = GetInShooting)) bool InShooting;
	bool GetInShooting(void) { return m_InShooting; }

	__declspec(property(get = GetScore, put = SetScore)) int Score;
	int GetScore(void) { return m_Score; }
	void SetScore(int Value) { m_Score = Value; }

private:
	void OnWallHit(void);

	__declspec(property(get = GetCenterDistancePercent)) int CenterDistancePercent;
	int GetCenterDistancePercent(void) 
	{
		int center = BoundingRectangle.Center.X,
			windowCenter = WIDTH / 2;

		if (center == windowCenter)
			return 0;

		int temp = (Abs((windowCenter - center)) / (float)windowCenter) * 100;

		if (center > windowCenter)
			temp *= -1;

		return temp;
	}

private:
	cInput *m_Input;
	cAudio *m_Audio;
	Vector m_Position;
	Vector m_Velocity;
	cSound *m_WallHit;
	cAnimation *m_IdleAnim, *m_ShootAnim;
	cAnimationPlayer *m_AnimPlayer;
	TextureFlip m_Flip;
	
	bool m_InShooting;

	cFont *m_Font;
	int m_Score;
};
