#pragma once

#include "Engine\cGameTime.h"
#include "Engine\cInput.h"
#include "Engine\cContentManager.h"
#include "Engine\cAudio.h"
#include "Engine\cSpriteBatch.h"

class cState
{
public:
	cState(cInput *Input, cContentManager *Content, cAudio *Audio);
	~cState(void);

	virtual void LoadState(void);
	virtual void HandleInput(void);
	virtual void Update(cGameTime *GameTime);
	virtual void Draw(cGameTime *GameTime, cSpriteBatch *SpriteBatch);

protected:
	__declspec(property(get = GetInput)) cInput *Input;
	cInput* GetInput(void) { return m_Input; }

	__declspec(property(get = GetContent)) cContentManager *Content;
	cContentManager* GetContent(void) { return m_Content; }

	__declspec(property(get = GetAudio))cAudio *Audio;
	cAudio* GetAudio(void) { return m_Audio; }

private:
	cInput *m_Input;
	cContentManager *m_Content;
	cAudio *m_Audio;
};
