﻿#include "cBirdKillerGame.h"
#include "Engine\cAudio.h"

cBirdKillerGame::cBirdKillerGame(void)
	: cGame(true, true, true)
{
	Window->SetIcon("Data\\Icon.png");
	
	Content->RootPath = "Data\\";
}

cBirdKillerGame::~cBirdKillerGame(void)
{

}

void cBirdKillerGame::LoadGame(void)
{
	m_GameState = new cGameState(Input, Content, AudioEngine);

	Window->ShowCursor = false;

	m_GameState->LoadState();
}

void cBirdKillerGame::Update(cGameTime* GameTime)
{
	//if (Input->EventOccurs())
	{
		if (Input->QuitOccurs() || Input->GetPressedKey() == SDLK_ESCAPE)
		{
			Exit();
		}
		else if (Input->GetPressedKey() == SDLK_F3)
		{
			SpriteBatch->SaveScreen(IntToString(GameTime->TotalRealTime) + ".bmp");
		}
	}

	m_GameState->Update(GameTime);

	cGame::Update(GameTime);
}

void cBirdKillerGame::Draw(cGameTime* GameTime)
{
	SpriteBatch->Clear(Color(100, 100, 100));

	m_GameState->Draw(GameTime, SpriteBatch);

	cGame::Draw(GameTime);
}
