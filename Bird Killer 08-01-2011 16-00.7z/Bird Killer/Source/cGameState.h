#pragma once

#include "Engine\Mathematics.h"
#include "Engine\cGameTime.h"
#include "Engine\cInput.h"
#include "Engine\cContentManager.h"
#include "Engine\cAudio.h"
#include "Engine\cSpriteBatch.h"
#include "cState.h"
#include "cPlayer.h"
#include "cBird.h"
#include "cBigBird.h"

class cGameState : 
	public cState
{
private:
	static const int MIN_BIRD_X;
	static const int MAX_BIRD_X;

public:
	cGameState(cInput *Input, cContentManager *Content, cAudio *Audio);
	~cGameState(void);

	void LoadState(void);
	void HandleInput(void);
	void Update(cGameTime *GameTime);
	void UpdateBirds(cGameTime *GameTime);
	void Draw(cGameTime *GameTime, cSpriteBatch *SpriteBatch);

private:
	void UpdateBirdGenerator(cGameTime *GameTime);
	
private:
	cTexture *m_Background1;
	cTexture *m_Background2;
	cPlayer *m_Player;
	cSound *m_Music;
	std::vector<cBird*> m_BirdList;
	std::vector<cBigBird*> m_BigBirdList;

	int m_BirdPreviousTime;
	float m_BirdDelayTime;
	int m_AddedCount;
	
	int m_BigBirdPreviousTime;
	float m_BigBirdDelayTime;

	cFont *m_Font;
};
