#pragma once

#include "Engine\cGame.h"
#include "cGameState.h"

class cBirdKillerGame : public cGame
{
public:
	static const int Width;
	static const int Height;

public:
	cBirdKillerGame(void);
	~cBirdKillerGame(void);

private:
	void LoadGame(void);
	void Update(cGameTime* GameTime);
	void Draw(cGameTime* GameTime);

private:
	cGameState *m_GameState;
};

