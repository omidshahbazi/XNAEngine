﻿#include "cPlayer.h"

const float cPlayer::MoveVelocity = 5.0f;

cPlayer::cPlayer(cInput *Input, cContentManager *Content, cAudio *Audio, Vector Position) :
	m_Input(Input),
	m_Audio(Audio),
	m_Position(Position)
{
	m_WallHit = NULL;
	m_AnimPlayer = new cAnimationPlayer();
	m_Flip = TextureFlip_None;

	m_IdleAnim = new cAnimation(Content->LoadTexture("Images\\Player\\Player.png"), 1.0f, false);
	m_IdleAnim->Texture->Effect->Origin = Vector(0, m_IdleAnim->Texture->Height);

	m_ShootAnim = new cAnimation(Content->LoadTexture("Images\\Player\\PlayerShoot.png"), 0.8f, false);
	m_ShootAnim->Texture->Effect->Origin = Vector(0, m_ShootAnim->Texture->Height);

	m_AnimPlayer->Play(m_IdleAnim);

	m_InShooting = false;

	m_Font = Content->LoadFont("Fonts\\Tahoma.ttf", 15);
	m_Score = 0;
}

cPlayer::~cPlayer(void)
{
	delete m_IdleAnim;
	delete m_ShootAnim;
	delete m_AnimPlayer;
}

void cPlayer::HandleInput()
{
	if (m_Input->GetDownedKey() == SDLK_LEFT || m_Input->GetDownedKey() == SDLK_a)
	{
		m_Velocity.X = -cPlayer::MoveVelocity;
		m_Flip = TextureFlip_FlipHorizontally;
	}

	if (m_Input->GetDownedKey() == SDLK_RIGHT || m_Input->GetDownedKey() == SDLK_d)
	{
		m_Velocity.X = +cPlayer::MoveVelocity;
		m_Flip = TextureFlip_None;
	}
	
	if (m_Input->EventOccurs())
	{
		if (m_Input->GetPressedKey() == SDLK_SPACE)
		{
			m_InShooting = true;
		}

		MouseEvent *me = m_Input->GetMouseMove();

		if (me != NULL)
		{
			if (m_Position.X > me->Location.X - m_AnimPlayer->Animation->Texture->Center.X)
				m_Flip = TextureFlip_FlipHorizontally;
			else if (m_Position.X < me->Location.X - m_AnimPlayer->Animation->Texture->Center.X)
				m_Flip = TextureFlip_None;

			m_Position.X = me->Location.X - m_AnimPlayer->Animation->Texture->Center.X;
		}

		me = m_Input->GetMouseEvent();

		if (me != NULL && me->Button == MouseButton_Left)
		{
			m_InShooting = true;
		}
	}
}

void cPlayer::HandleCollision()
{
	if (BoundingRectangle.Left < 0)
	{
		OnWallHit();

		m_Position.X -= BoundingRectangle.Left;
	}
	
	if (BoundingRectangle.Right > WIDTH)
	{
		OnWallHit();

		int x = ((m_AnimPlayer->Animation->FrameWidth - BoundingRectangle.Width) / 2.0f);
		
		m_Position.X = WIDTH - m_AnimPlayer->Animation->FrameWidth + x;
	}
}

void cPlayer::Update(cGameTime *GameTime)
{
	m_InShooting = false;

	HandleInput();

	if (m_InShooting)
		m_AnimPlayer->Play(m_ShootAnim);
	else
		m_AnimPlayer->Play(m_IdleAnim);

	m_Position += m_Velocity;

	HandleCollision();

	m_Velocity = Vector(0);

	m_AnimPlayer->Animation->Texture->Effect->Flip = m_Flip;
}

void cPlayer::Draw(cGameTime *GameTime, cSpriteBatch *SpriteBatch)
{
	m_AnimPlayer->Draw(GameTime, SpriteBatch, m_Position);

	SpriteBatch->DrawString(m_Font, "Score : " + IntToString(m_Score), Vector(10, 25), Color(255, 100, 50));
}

void cPlayer::OnWallHit()
{
	if (m_WallHit == NULL || m_WallHit->IsPaused || m_WallHit->IsFinished)
	{
		m_WallHit = m_Audio->FromFile("Data\\Sounds\\PlayerWallHit.wav");

		m_WallHit->Volume = 80;
		m_WallHit->Pan = CenterDistancePercent;

		m_WallHit->Resume();
	}
}