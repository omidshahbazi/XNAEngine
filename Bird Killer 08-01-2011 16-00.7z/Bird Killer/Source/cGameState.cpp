#include "cGameState.h"

const int cGameState::MIN_BIRD_X = (HEIGHT / 2) - 400;
const int cGameState::MAX_BIRD_X = (HEIGHT / 2) + 400;

cGameState::cGameState(cInput *Input, cContentManager *Content, cAudio *Audio) :
	cState(Input, Content, Audio)
{
	m_BirdPreviousTime = 0;
	m_BirdDelayTime = 2.0f;
	m_AddedCount = 0;
	
	m_BigBirdPreviousTime = 0;
}

cGameState::~cGameState(void)
{
}

void cGameState::LoadState()
{
	cState::LoadState();

	m_Music = Audio->FromFile("Data\\Sounds\\Music.mp3", true);

	m_Background1 = Content->LoadTexture("Backgrounds\\1.png");

	m_Background2 = Content->LoadTexture("Backgrounds\\2.png");

	m_Player = new cPlayer(Input, Content, Audio, Vector(0, HEIGHT));

	m_Font = Content->LoadFont("Fonts\\Tahoma.ttf", 12);
	
	m_Music->Resume();
}

void cGameState::HandleInput()
{
}

void cGameState::Update(cGameTime *GameTime)
{
	if (!GameTime->IsRunningSlowly)
	{
		HandleInput();

		UpdateBirds(GameTime);

		m_Player->Update(GameTime);
	}

	cState::Update(GameTime);
}

void cGameState::UpdateBirds(cGameTime *GameTime)
{
	UpdateBirdGenerator(GameTime);

	std::vector<cBird*>::iterator it = m_BirdList.begin();

	while (it != m_BirdList.end())
	{
		cBird *bird = *it;

		bird->Update(GameTime);

		if (bird->CanRemove)
        {
			if (it == m_BirdList.begin())
			{
				m_BirdList.erase(it);

				delete bird;
			}
			else
			{
				m_BirdList.erase(it--);

				delete bird;
			}

			it = m_BirdList.begin();
        }
		else
			it++;
	}

	std::vector<cBigBird*>::iterator it_Big = m_BigBirdList.begin();

	while (it_Big != m_BigBirdList.end())
	{
		cBigBird *bird = *it_Big;

		bird->Update(GameTime);

		if (bird->CanRemove)
        {
			if (it_Big == m_BigBirdList.begin())
			{
				m_BigBirdList.erase(it_Big);

				delete bird;
			}
			else
			{
				m_BigBirdList.erase(it_Big--);

				delete bird;
			}

			it_Big = m_BigBirdList.begin();
        }
		else
			it_Big++;
	}
}

void cGameState::UpdateBirdGenerator(cGameTime *GameTime)
{
	if (GameTime->TotalRealTime - m_BirdPreviousTime > m_BirdDelayTime * 1000)
	{
		int x = Random(cGameState::MIN_BIRD_X / 100, cGameState::MAX_BIRD_X / 100);

		m_BirdList.push_back(new cBird(Content, Audio, Vector(x * 100, -(x * 3)), Vector(2, 4), Random(1, 6), m_Player));

		m_BirdPreviousTime = GameTime->TotalRealTime;

		m_AddedCount++;

		if (m_AddedCount > 10 && m_BirdDelayTime > 0.6f)
		{
			m_AddedCount = 0;
			m_BirdDelayTime -= 0.2;
		}
	}

	if (GameTime->TotalRealTime - m_BigBirdPreviousTime > 10 * 1000)
	{
		int x = Random(cGameState::MIN_BIRD_X / 100, cGameState::MAX_BIRD_X / 100);

		m_BigBirdList.push_back(new cBigBird(Content, Audio, Vector(-x * 100, -(x * 3)), Vector(2, 4), Random(1, 4), m_Player));

		m_BigBirdPreviousTime = GameTime->TotalRealTime;
	}
}

void cGameState::Draw(cGameTime *GameTime, cSpriteBatch *SpriteBatch)
{
	if (!GameTime->IsRunningSlowly)
	{
		SpriteBatch->Clear(Color(146, 204, 222));

		SpriteBatch->Draw(m_Background1, Vector(0, 120));

		SpriteBatch->Draw(m_Background2, Rectangle(Vector(), Vector(481, 150)), Vector(-10, 300));
		SpriteBatch->Draw(m_Background2, Rectangle(Vector(0, 193), Vector(481, 94)), Vector(0, 380));

		m_Player->Draw(GameTime, SpriteBatch);

		for (int i = 0; i < m_BirdList.size(); i++)
			m_BirdList[i]->Draw(GameTime, SpriteBatch);

		for (int i = 0; i < m_BigBirdList.size(); i++)
			m_BigBirdList[i]->Draw(GameTime, SpriteBatch);

		SpriteBatch->Draw(m_Background2, Rectangle(Vector(0, 155), Vector(481, 40)), Vector(0, 464));

		SpriteBatch->DrawString(m_Font, "Press F3 to create snapshot", Vector(10), Color(0, 0, 0));
	}

	cState::Draw(GameTime, SpriteBatch);
}